@echo off
cd /d "%~dp0EXORCIZAR-Dono"
call INICIAR-DONO.bat
