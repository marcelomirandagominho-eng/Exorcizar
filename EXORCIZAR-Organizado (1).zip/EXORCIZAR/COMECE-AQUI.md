# EXORCIZAR — pacote organizado

Este é o conjunto consolidado das suas pastas. Tem três programas: **EXORCIZAR-Cloudflare** (site já publicado), **EXORCIZAR-Tracker-Nuvem** (API e coletor da segunda conta) e **EXORCIZAR-Dono** (painel de administração). O coletor local antigo não é necessário para operar o tracker na nuvem.

## Começar agora

1. Extraia este pacote numa pasta nova. Feche o CMD do dono antigo antes de abrir o novo.
2. Abra **ABRIR-DONO.bat**. Seus sete registros de licença, a assinatura e a chave pública já estão incluídos, conforme as pastas que você enviou. Pressione **Ctrl + F5** no navegador para carregar o rework.
3. Execute **ATUALIZAR-TRACKER.bat**. Ele instala o publicador se necessário e atualiza somente o Worker **exorcizar-tracker da segunda conta**. Autorize pelo **Edge**. Os IDs do banco, a migração do Durable Object e a configuração publicada foram preservados; não precisa copiar wrangler.json de outra pasta.
4. No dono, abra **Tracker na nuvem**, clique em **Reconectar contas**, aguarde e consulte **Atualizar status**. O pacote inclui um ajuste do Identify para usar os campos do SDK do seu coletor local e mostra também o motivo de fechamento enviado pelo Gateway.
5. Quando uma conta estiver conectada, envie uma mensagem de teste num servidor dela e confira o registro no site. O processo e o banco ficam na Cloudflare; o dono pode ser fechado e o PC desligado depois da configuração.

O erro real `4000 / identify_sent` ainda não foi confirmado como resolvido. A compatibilidade do pacote de login foi ajustada, mas os testes com Gateway simulado não substituem o teste com sua conta. Se persistir, use **Copiar diagnóstico** e envie o resultado do status, sem tokens.

## Onde está cada coisa

| Arquivo/pasta | Finalidade |
| --- | --- |
| ABRIR-DONO.bat | Abrir o painel de dono atualizado |
| ATUALIZAR-TRACKER.bat | Publicar o código do tracker na segunda conta sem reenviar tokens |
| CONFIGURAR-CONTAS.bat | Editar o arquivo de tokens das alts |
| EXORCIZAR-Dono/dados | Assinatura original, chave pública e sete licenças preservadas |
| EXORCIZAR-Tracker-Nuvem/contas/tokens.txt | Sua lista de contas para configuração do segredo na Cloudflare |
| EXORCIZAR-Tracker-Nuvem/.tracker-link.json | Configuração privada já existente entre as contas |
| EXORCIZAR-Tracker-Nuvem/dados/legado/tracker.sqlite | Backup preservado do banco do coletor local antigo |
| EXORCIZAR-Cloudflare | Código e configuração do site que já estava publicado |

Para **trocar ou adicionar tokens**, salve `contas/tokens.txt` com um token de alt por linha e execute **EXORCIZAR-Tracker-Nuvem/PUBLICAR-COLETOR-NUVEM.bat**. Essa operação envia a lista atual para `TRACKER_ACCOUNTS_JSON` na segunda conta. Para atualizar apenas o código, use **ATUALIZAR-TRACKER.bat**.

O site principal e os CLs não precisam ser republicados para aplicar o rework local do dono e esta atualização do tracker. A pasta do site foi mantida como fonte de manutenção e contém a configuração publicada. Os segredos remotos que já existem não são recriados por este atualizador.

## Painel de dono

- **Visão geral:** contagem de licenças, ativações e estado real do coletor.
- **Licenças:** geração, busca, filtro por status, cópia, consulta, revogação e liberação de vínculo. Resgate, vencimento e prazo restante continuam sendo calculados pelos registros existentes.
- **Tracker na nuvem:** iniciar, parar, reconectar, consultar status, ver cada conta e copiar o diagnóstico. O catálogo de servidores é automático, sem formulário de seleção para coleta.
- **Acesso pela key:** a licença ativa e a conta Discord vinculada já liberam o tracker. Não há cadastro manual de ID nem liberação individual de servidores por cliente. O catálogo administrativo permanece somente no dono.
- **Conexões:** URLs da equipe/site e chave pública. Coletores externos antigos ficaram recolhidos numa seção avançada; suas credenciais não são necessárias para o coletor nativo.

A atualização do status na tela ocorre a cada 15 segundos enquanto a página Tracker está visível. A sincronização de keys continua a cada 30 segundos. Os controles do tracker não aguardam a fila de sincronização das keys.

## Dados preservados e limpeza

As duas cópias de dono enviadas tinham os mesmos sete IDs e a mesma assinatura. Foi mantida a cópia com a confirmação de sincronização mais recente. Os arquivos `assinatura-privada.json`, `CHAVE-PUBLICA.json` e `licencas.json` foram copiados byte a byte dessa versão, e cada key foi verificada com a chave pública. Nenhuma assinatura de dono foi gerada novamente.

Foram removidos do pacote a pasta `Nova pasta` duplicada, o programa do coletor local, instaladores repetidos, caches, `node_modules`, arquivos temporários de publicação e cópias antigas de configuração que não são necessárias. As dependências do publicador são reinstaladas automaticamente. O banco SQLite local antigo foi conservado como backup; ele não é importado automaticamente no Durable Object.

O arquivo `pastas 1.zip` chegou sem o índice final do ZIP e terminou durante uma dependência do workerd. Os arquivos completos de aplicação foram recuperados e conferidos; o tracker e o dono também estavam no segundo ZIP, que estava completo. Não foi necessário reutilizar dependências incompletas.

Este pacote é pessoal: contém seus dados e configurações. Não é o pacote de frontend para clientes.

## Verificação e limites

Passaram 39 testes de interface, licença/OAuth, isolamento entre contas, permissões, bloqueios, cooldown, sincronização, Gateway simulado e publicadores. O runtime workerd foi testado com Durable Object SQLite, WebSocket simulado, alarme, fila e D1. O painel foi inspecionado no navegador com dados fictícios. Os dois Workers foram compilados em dry-run. Não houve publicação na sua conta nem autenticação com tokens reais durante a preparação.

Os oito IDs protegidos permanecem protegidos. DMs e grupos privados continuam fora da coleta. A coleta nativa habilita os servidores informados pelas contas, inclusive os antes desabilitados, mas só recebe o que o Gateway disponibiliza a elas. Não recupera fotos/nicks anteriores ao que foi observado, não grava áudio de call e não faz varredura completa de mensagens antigas. Os limites de cotas e armazenamento do plano gratuito continuam valendo.

Para executar os testes de desenvolvimento: instale Node.js 22.13+, rode `npm install` nesta pasta e depois `npm test`. O painel de dono em si usa apenas módulos nativos e abre pelo BAT sem instalar essas dependências de teste.

## Liberação automática pela key

Execute **ATUALIZAR-TRACKER.bat** e autorize a segunda conta (Edge). Feche o dono antigo e abra **ABRIR-DONO.bat** nesta pasta. A mudança de acesso será aplicada pela API do tracker; o site principal já valida a licença antes de encaminhar as consultas. Não é necessário republicar o site principal para esta mudança quando a conexão entre as duas contas já está configurada.

O coletor e os tokens de alt foram mantidos. Esta mudança de acesso não corrige o erro de conexão 4000 do Gateway. As oito proteções de IDs e o cooldown de dez segundos continuam ativos.
