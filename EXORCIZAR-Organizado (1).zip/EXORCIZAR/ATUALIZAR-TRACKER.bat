@echo off
cd /d "%~dp0EXORCIZAR-Tracker-Nuvem"
call ATUALIZAR-COLETOR.bat
