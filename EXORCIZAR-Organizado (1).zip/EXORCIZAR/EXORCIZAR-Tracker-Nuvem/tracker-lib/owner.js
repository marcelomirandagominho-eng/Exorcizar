const LC_PLANS=Object.freeze({'7d':{days:7,label:'7 dias'},'30d':{days:30,label:'30 dias'},'1y':{days:365,label:'1 ano'},lifetime:{days:null,label:'Vitalícia'}});
const lcEncoder=new TextEncoder();
const lcEncode=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const lcDecode=value=>{if(!/^[A-Za-z0-9_-]+$/.test(value))throw Error();return Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));};
const lcUUID=value=>typeof value==='string'&&/^[a-f\d]{8}-[a-f\d]{4}-[a-f\d]{4}-[a-f\d]{4}-[a-f\d]{12}$/i.test(value);
const lcDigest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',lcEncoder.encode(value))),x=>x.toString(16).padStart(2,'0')).join('');
class LicenseError extends Error{constructor(message,status=400,code='LICENSE_INVALID'){super(message);this.status=status;this.code=code;}}
function lcPublicKey(env){try{const jwk=JSON.parse(env.OWNER_PUBLIC_JWK||'null');if(!jwk||jwk.kty!=='EC'||jwk.crv!=='P-256'||jwk.d||!/^[-\w]{43}$/.test(jwk.x)||!/^[-\w]{43}$/.test(jwk.y))throw Error();return {kty:'EC',crv:'P-256',x:jwk.x,y:jwk.y};}catch{throw new LicenseError('O gerador do dono ainda não foi vinculado ao site.',503,'ISSUER_NOT_CONFIGURED');}}
async function lcIssuer(env){return lcDigest(JSON.stringify(lcPublicKey(env)));}
async function lcVerify(value,env,kind='license',now=Date.now()){
 const jwk=lcPublicKey(env);
 try{if(typeof value!=='string'||value.length>4096)throw Error();const [body,sig,...extra]=value.replace(/^EXC\./,'').split('.');if(!body||!sig||extra.length)throw Error();const key=await crypto.subtle.importKey('jwk',jwk,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,lcDecode(sig),lcEncoder.encode(body)))throw Error();const payload=JSON.parse(new TextDecoder().decode(lcDecode(body)));if(payload.kind!==kind||payload.v!==1||!lcUUID(payload.id))throw Error();if(kind==='license'&&(!Object.hasOwn(LC_PLANS,payload.plan)||!Number.isSafeInteger(payload.createdAt)||payload.createdAt<1||payload.createdAt>now+300000))throw Error();if(kind==='owner'&&(!['status','revoke','reset','tracker-state','tracker-save','tracker-grant','tracker-create','tracker-revoke','tracker-cloud-status','tracker-cloud-start','tracker-cloud-stop','tracker-cloud-reconnect'].includes(payload.action)||!Number.isSafeInteger(payload.at)||Math.abs(now-payload.at)>60000||!lcUUID(payload.nonce)))throw Error();return payload;}catch{throw new LicenseError(kind==='owner'?'Autorização do dono inválida ou expirada.':'Assinatura ou key inválida.',401);}
}

export const verifyOwner=(proof,env)=>lcVerify(proof,env,'owner');
