@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Instale Node.js 22.13 ou superior.
 pause
 exit /b 1
)
if not exist "node_modules\wrangler\bin\wrangler.js" (
 call npm install
 if errorlevel 1 (
  echo Falha ao instalar o Wrangler.
  pause
  exit /b 1
 )
)
node ativar-coletor.mjs
pause
