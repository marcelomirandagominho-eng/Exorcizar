CREATE INDEX IF NOT EXISTS tracker_events_message ON tracker_events(guild_id,json_extract(body,'$.messageId'),seq);
