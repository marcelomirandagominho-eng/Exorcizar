CREATE TABLE IF NOT EXISTS tracker_collectors(id TEXT PRIMARY KEY,label TEXT NOT NULL,token_hash TEXT UNIQUE NOT NULL,revoked INTEGER NOT NULL DEFAULT 0,last_seen INTEGER);
CREATE TABLE IF NOT EXISTS tracker_guilds(id TEXT PRIMARY KEY,name TEXT,enabled INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS tracker_grants(user_id TEXT NOT NULL,guild_id TEXT NOT NULL,PRIMARY KEY(user_id,guild_id));
CREATE TABLE IF NOT EXISTS tracker_consents(user_id TEXT PRIMARY KEY,accepted_at INTEGER NOT NULL,version TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tracker_events(seq INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT UNIQUE NOT NULL,guild_id TEXT NOT NULL,user_id TEXT,channel_id TEXT,type TEXT NOT NULL,observed_at INTEGER NOT NULL,content TEXT NOT NULL,body TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS tracker_events_user ON tracker_events(user_id,guild_id,seq);
CREATE INDEX IF NOT EXISTS tracker_events_guild ON tracker_events(guild_id,seq);
CREATE TABLE IF NOT EXISTS tracker_identity(guild_id TEXT NOT NULL,user_id TEXT NOT NULL,field TEXT NOT NULL,value TEXT,observed_at INTEGER NOT NULL,PRIMARY KEY(guild_id,user_id,field));
CREATE TABLE IF NOT EXISTS tracker_history(id TEXT PRIMARY KEY,guild_id TEXT NOT NULL,user_id TEXT NOT NULL,field TEXT NOT NULL,value TEXT NOT NULL,observed_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS tracker_history_user ON tracker_history(user_id,guild_id,observed_at);
CREATE TABLE IF NOT EXISTS tracker_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO tracker_settings VALUES('auto_collect','true') ON CONFLICT(key) DO NOTHING;

CREATE TABLE IF NOT EXISTS owner_nonces(nonce TEXT PRIMARY KEY,expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS tracker_lookups(user_id TEXT PRIMARY KEY,target TEXT NOT NULL,changed_at INTEGER NOT NULL);
