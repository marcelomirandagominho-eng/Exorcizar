@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Instale Node.js 22.13 ou superior.
 pause
 exit /b 1
)
if not exist "node_modules\wrangler\bin\wrangler.js" (
 echo Preparando o publicador do tracker...
 call npm install
 if errorlevel 1 (
  echo A instalacao falhou. Nenhuma publicacao foi iniciada.
  pause
  exit /b 1
 )
)
node atualizar-coletor.mjs
pause
