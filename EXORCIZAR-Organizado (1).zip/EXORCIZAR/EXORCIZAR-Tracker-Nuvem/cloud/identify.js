// Identify fields ported from the installed local collector SDK (discord.js-selfbot-v13 3.7.1).
const template={
  "capabilities": 0,
  "properties": {
    "os": "Windows",
    "browser": "Discord Client",
    "release_channel": "stable",
    "client_version": "1.0.9210",
    "os_version": "10.0.19044",
    "os_arch": "x64",
    "app_arch": "x64",
    "system_locale": "en-US",
    "has_client_mods": false,
    "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9210 Chrome/134.0.6998.205 Electron/35.3.0 Safari/537.36",
    "browser_version": "35.3.0",
    "os_sdk_version": "19044",
    "client_build_number": 455964,
    "native_build_number": 69976,
    "client_event_source": null,
    "client_app_state": "focused"
  },
  "compress": false,
  "client_state": {
    "guild_versions": {}
  }
};
export function identifyPayload(token){return {...template,properties:{...template.properties,client_launch_id:crypto.randomUUID(),launch_signature:crypto.randomUUID(),client_heartbeat_session_id:crypto.randomUUID()},client_state:{guild_versions:{}},token};}
