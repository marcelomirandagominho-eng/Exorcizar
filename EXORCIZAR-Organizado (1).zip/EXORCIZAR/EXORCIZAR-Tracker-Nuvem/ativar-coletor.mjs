import {readFile,writeFile,rename,access} from 'node:fs/promises';import {spawn} from 'node:child_process';import {createInterface} from 'node:readline/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),rl=createInterface({input:process.stdin,output:process.stdout});let tokens=[];
const exists=async p=>{try{await access(p);return true;}catch{return false;}};
function parse(text){
 text=text.replace(/\x1b\[[0-9;]*m/g,'').trim();try{return JSON.parse(text);}catch{}
 for(let start=0;start<text.length;start++){
  if(!'[{' .includes(text[start]))continue;
  let depth=0,quoted=false,escaped=false;
  for(let end=start;end<text.length;end++){
   const c=text[end];
   if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;continue;}
   if(c==='"')quoted=true;else if(c==='['||c==='{')depth++;else if(c===']'||c==='}'){depth--;if(depth===0){try{return JSON.parse(text.slice(start,end+1));}catch{break;}}}
  }
 }
 throw Error('O Wrangler não retornou JSON válido. Confira a saída.');
}
const redact=value=>tokens.reduce((s,token)=>s.split(token).join('[TOKEN OCULTO]'),String(value));
async function save(file,value){await writeFile(file+'.tmp',JSON.stringify(value,null,2)+'\n',{mode:0o600});await rename(file+'.tmp',file);}
try{
 const configFile=path.join(root,'wrangler.json'),original=await readFile(configFile,'utf8'),config=JSON.parse(original);
 if(config.name!=='exorcizar-tracker'||config.account_id!=='9574a9dc604400197bc09b6d1621c7b0')throw Error('Este publicador só atualiza o Worker do tracker na segunda conta. Use a pasta EXORCIZAR-Tracker-Nuvem já configurada.');
 const defaultFile=path.join(root,'contas','tokens.txt');let file=defaultFile;
 if(await exists(defaultFile)){const answer=await rl.question('Usar as contas de contas/tokens.txt? Enter = sim; ou informe outro caminho: ');if(answer.trim())file=answer.trim().replace(/^"|"$/g,'');}else file=(await rl.question('Caminho completo do arquivo com um token de conta por linha: ')).trim().replace(/^"|"$/g,'');
 tokens=[...new Set((await readFile(file,'utf8')).replace(/^\uFEFF/,'').split(/\r?\n/).map(x=>x.trim()).filter(x=>x&&!x.startsWith('#')))];
 if(!tokens.length||tokens.some(t=>/\s/.test(t)||t.length>4096))throw Error('O arquivo de contas está vazio ou contém uma entrada inválida.');
 const accountsJson=JSON.stringify(tokens.map((token,i)=>({token,label:'Conta '+(i+1)})));if(Buffer.byteLength(accountsJson)>28000)throw Error('A lista excede o tamanho seguro de um segredo Cloudflare. Reduza o arquivo de contas.');
 console.log(tokens.length+' conta(s) serão configuradas como segredo no Worker. Os tokens não serão impressos.');
 const cli=path.join(root,'node_modules/wrangler/bin/wrangler.js');if(!await exists(cli))throw Error('Wrangler não instalado. Inicie pelo PUBLICAR-COLETOR-NUVEM.bat.');
 const run=(args,options={})=>new Promise((resolve,reject)=>{const p=spawn(process.execPath,[cli,...args,'--config','wrangler.json'],{cwd:root,env:{...process.env,CI:'true'},stdio:['pipe','pipe','pipe']});let output='';for(const s of [p.stdout,p.stderr])s.on('data',chunk=>{output+=chunk;if(!options.privateInput)process.stdout.write(redact(chunk));});p.on('error',reject);p.on('exit',code=>code===0?resolve(output):reject(Error('Falhou: wrangler '+args.join(' ')+'. Confira a mensagem acima.')));p.stdin.end(options.input);});
 if(!await exists(configFile+'.antes-coletor-nuvem'))await writeFile(configFile+'.antes-coletor-nuvem',original,{mode:0o600});
 const bindings=config.durable_objects?.bindings||[];const current=bindings.find(b=>b.name==='CLOUD_COLLECTOR');if(current&&current.class_name!=='CloudCollector')throw Error('Já existe outro binding CLOUD_COLLECTOR; parei para não trocar seu destino.');
 config.durable_objects={...config.durable_objects,bindings:current?bindings:[...bindings,{name:'CLOUD_COLLECTOR',class_name:'CloudCollector'}]};
 config.migrations=config.migrations||[];if(!config.migrations.some(m=>m.tag==='exorcizar-cloud-v1'))config.migrations.push({tag:'exorcizar-cloud-v1',new_sqlite_classes:['CloudCollector']});
 const crons=[...new Set([...(config.triggers?.crons||[]),'*/5 * * * *'])];if(crons.length>3)throw Error('Já existem três Cron Triggers; ajuste a configuração antes de continuar.');config.triggers={...config.triggers,crons};config.keep_vars=true;config.preview_urls=false;await save(configFile,config);
 console.log('\n1/5 · Conferindo o coletor no runtime dos Workers.');await run(['deploy','--dry-run','--outdir','.preflight']);
 await rl.question('\n2/5 · Autorize somente a SEGUNDA conta, do tracker, no Edge. Pressione Enter para abrir o login: ');await run(['login']);
 const secrets=parse(await run(['secret','list','--format','json']));if(!Array.isArray(secrets)||!['OWNER_PUBLIC_JWK','TRACKER_SHARED_SECRET'].every(name=>secrets.some(s=>s.name===name)))throw Error('Não confirmei a conexão e a chave pública existentes do tracker. Nenhum segredo existente foi substituído.');
 const list=parse(await run(['d1','list','--json'])),db=Array.isArray(list)?list.find(row=>row.name==='exorcizar-tracker'):null;if(!db?.uuid)throw Error('Banco exorcizar-tracker não encontrado na segunda conta.');
 config.d1_databases=[{binding:'DB',database_name:'exorcizar-tracker',database_id:db.uuid,migrations_dir:'migrations'}];await save(configFile,config);
 console.log('\n3/5 · Preservando o banco e aplicando o índice de consulta de mensagens.');await run(['d1','migrations','apply','DB','--remote']);
 console.log('\n4/5 · Configurando as contas no segredo TRACKER_ACCOUNTS_JSON.');await run(['secret','bulk'],{input:JSON.stringify({TRACKER_ACCOUNTS_JSON:accountsJson}),privateInput:true});
 console.log('\n5/5 · Publicando o coletor e o watchdog na segunda conta.');await run(['deploy']);
 console.log('\nPUBLICADO. Reinicie o painel de dono atualizado e clique em Coletor na Cloudflare > Iniciar na nuvem. Depois confira Atualizar status. Quando mostrar conectado, o CMD e o PC podem ser fechados.\nNão inicie o coletor local ao mesmo tempo. O site, o banco de licenças e os CLs da primeira conta não foram publicados por este script.\nO plano gratuito continua sujeito às cotas de duração, requisições, armazenamento e escritas. O funcionamento com contas reais precisa ser conferido no status após a publicação.');
}catch(e){console.error('\nPublicação interrompida: '+redact(e.message));process.exitCode=1;}finally{rl.close();tokens=[];}
