import {test} from 'node:test';import assert from 'node:assert/strict';import {DatabaseSync} from 'node:sqlite';import {readFile} from 'node:fs/promises';
import worker from '../nuvem/worker.mjs';import {sign} from '../lib/license.mjs';import {status,remaining} from '../lib/status.mjs';
test('four local admins share generated keys and read actual activation/expiry; signatures and replay are enforced',async()=>{
const sql=new DatabaseSync(':memory:');sql.exec('CREATE TABLE licenses(id TEXT PRIMARY KEY,discord_id TEXT,activated_at INTEGER,expires_at INTEGER,revoked INTEGER,revision INTEGER)');sql.exec(await readFile(new URL('../nuvem/migrations/0001_team_catalog.sql',import.meta.url),'utf8'));
const DB={withSession:()=>DB,prepare(query){const mk=params=>({query,params,bind:(...p)=>mk(p)});return mk([])},async batch(rows){sql.exec('BEGIN');try{const r=rows.map(s=>({results:sql.prepare(s.query).all(...s.params)}));sql.exec('COMMIT');return r;}catch(e){sql.exec('ROLLBACK');throw e;}}};
const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']),privateKey=await crypto.subtle.exportKey('jwk',pair.privateKey),pub=await crypto.subtle.exportKey('jwk',pair.publicKey),env={DB,OWNER_PUBLIC_JWK:JSON.stringify(pub)};
const make=async(action,id,extra={})=>({proof:await sign({kind:'owner',v:1,id,action,at:Date.now(),nonce:crypto.randomUUID(),...extra},privateKey)});
const call=body=>worker.fetch(new Request('https://team.test/api/team',{method:'POST',body:JSON.stringify(body)}),env);
const id=crypto.randomUUID(),now=Date.now(),key='EXC.'+await sign({kind:'license',v:1,id,plan:'7d',createdAt:now},privateKey);
const signed=await make('team-register',id,{key,note:'Cliente teste'});assert.equal((await call(signed)).status,200);assert.equal((await call(signed)).status,409);
for(let admin=0;admin<4;admin++){const r=await(await call(await make('team-list',crypto.randomUUID()))).json();assert.equal(r.licenses[0].key,key);assert.equal(status({...r.licenses[0],checkedAt:now}),'Aguardando ativação');}
sql.prepare('INSERT INTO licenses VALUES (?,?,?,?,?,?)').run(id,'123456789012345678',now,now+86400000,0,0);
let row=(await(await call(await make('team-list',crypto.randomUUID()))).json()).licenses[0];assert.equal(status(row),'Ativa');assert.equal(remaining(row,now),'1d 0min');assert.equal(row.remote.userId,'123456789012345678');assert.equal(status(row,now+86400001),'Expirada');
sql.prepare('UPDATE licenses SET discord_id=NULL WHERE id=?').run(id);row=(await(await call(await make('team-list',crypto.randomUUID()))).json()).licenses[0];assert.equal(status(row),'Vínculo liberado');assert.equal(row.remote.expiresAt,now+86400000);
sql.prepare('UPDATE licenses SET revoked=1 WHERE id=?').run(id);row=(await(await call(await make('team-list',crypto.randomUUID()))).json()).licenses[0];assert.equal(status(row),'Revogada');
assert.equal((await call({proof:'bad'})).status,400);const forged=await make('team-register',id,{key:key+'x'});assert.equal((await call(forged)).status,400);
const req=new Request('https://team.test/api/team',{method:'POST',headers:{Origin:'https://evil.test'},body:JSON.stringify(await make('team-list',crypto.randomUUID()))});assert.equal((await worker.fetch(req,env)).status,403);sql.close();
});
test('unconfirmed, reset, expired and lifetime statuses are distinct; countdown starts at redemption',()=>{assert.equal(status({}),'Ainda não consultada');assert.equal(remaining({}),'Prazo começa no resgate');const row={remote:{activatedAt:1000,expiresAt:null,userId:'1'}};assert.equal(status(row),'Ativa');assert.equal(remaining(row),'Vitalícia');assert.equal(remaining({remote:{activatedAt:1000,expiresAt:60000}},59999),'1min');assert.equal(remaining({remote:{activatedAt:1000,expiresAt:60000}},60000),'Expirada');});
