import {readFile,writeFile} from 'node:fs/promises';
const keys=JSON.parse(await readFile(new URL('../dados/assinatura-privada.json',import.meta.url),'utf8'));
if(!keys.public||keys.public.d)throw Error('Copie sua pasta dados original antes de publicar.');
await writeFile(new URL('wrangler.json',import.meta.url),JSON.stringify({name:'exorcizar-admin',account_id:'a03366728c6a2608a8f894b99c07d938',main:'worker.mjs',compatibility_date:'2026-11-12',workers_dev:true,preview_urls:false,vars:{OWNER_PUBLIC_JWK:JSON.stringify(keys.public)},d1_databases:[{binding:'DB',database_name:'exorcizar-licenses',database_id:'11a17878-75e8-4dff-811f-f1667d4d8b49',migrations_dir:'migrations'}]},null,2));
console.log('Configuração pronta. Apenas a chave pública será enviada.');
