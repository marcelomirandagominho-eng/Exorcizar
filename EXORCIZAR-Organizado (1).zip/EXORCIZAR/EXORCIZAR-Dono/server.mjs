import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {status} from './lib/status.mjs';
import {sign,PLANS} from './lib/license.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const dataDir=process.env.EXORCIZAR_DATA_DIR||path.join(root,'dados');
await fs.mkdir(dataDir,{recursive:true,mode:0o700});
const read=async(name,fallback)=>{try{return JSON.parse(await fs.readFile(path.join(dataDir,name),'utf8'));}catch(e){if(e.code==='ENOENT')return fallback;throw e;}};
const write=async(name,value)=>{const f=path.join(dataDir,name);await fs.writeFile(f+'.tmp',JSON.stringify(value,null,2),{mode:0o600});await fs.rename(f+'.tmp',f);};
let keys=await read('assinatura-privada.json',null);
if(!keys)throw Error('Copie sua pasta dados original para este painel antes de iniciar. A assinatura existente deve ser preservada.');
await fs.writeFile(path.join(dataDir,'CHAVE-PUBLICA.json'),JSON.stringify(keys.public));
let licenses=await read('licencas.json',[]),config=await read('config.json',{siteUrl:'https://exorcizam.site',teamUrl:'https://exorcizar-admin.yeencapa011.workers.dev'});
const port=Number(process.env.OWNER_PORT||4180),origin=`http://127.0.0.1:${port}`,csrf=randomBytes(32).toString('hex');
let queue=Promise.resolve(),syncJob=null;
function scheduleSync(){if(syncJob)return syncJob;const task=queue.then(async()=>{try{return await syncTeam();}catch(e){syncError=e.message;throw e;}});queue=task.catch(()=>{});syncJob=task;task.then(()=>{syncJob=null;},()=>{syncJob=null;});return task;}

function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
async function cloud(action,id,extra={}){
  if(!config.siteUrl)throw Error('Configure primeiro a URL do site dos usuários.');
  const proof=await sign({kind:'owner',v:1,action,id,at:Date.now(),nonce:crypto.randomUUID(),...extra},keys.private);
  const r=await fetch(action.startsWith('team-')?(config.teamUrl||'https://exorcizar-admin.yeencapa011.workers.dev')+'/api/team':config.siteUrl+(action.startsWith('tracker-')?'/api/tracker/owner':'/api/owner/action'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({proof}),signal:AbortSignal.timeout(20000),redirect:'error'});
  let b;try{b=await r.json();}catch{throw Error('O site não retornou uma resposta válida.');}if(!r.ok)throw Error(b.error||'Falha ao sincronizar.');return b;
}
let lastSync=null,syncError=null;
async function syncTeam(){
 const records=[];let cursor='';do{const page=await cloud('team-list',crypto.randomUUID(),{cursor});records.push(...page.licenses);cursor=page.next;}while(cursor);
 const known=new Set(records.map(x=>x.id));let added=false;
 for(const row of licenses){if(!known.has(row.id)){await cloud('team-register',row.id,{key:row.key,note:row.note});added=true;}}
 if(added){records.length=0;cursor='';do{const page=await cloud('team-list',crypto.randomUUID(),{cursor});records.push(...page.licenses);cursor=page.next;}while(cursor);}
 const checkedAt=Date.now();licenses=records.map(row=>({...row,checkedAt,status:status({...row,checkedAt})})).sort((a,b)=>b.createdAt-a.createdAt);await write('licencas.json',licenses);lastSync=checkedAt;syncError=null;return {ok:true,lastSync};
}
const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");res.setHeader('Referrer-Policy','no-referrer');
  if(req.headers.host!==`127.0.0.1:${port}`)return json(res,403,{error:'Host não permitido.'});
  const url=new URL(req.url,origin);
  try{
    if(req.method==='GET'&&url.pathname==='/api/state')return json(res,200,{csrf,licenses,siteUrl:config.siteUrl,teamUrl:config.teamUrl||'https://exorcizar-admin.yeencapa011.workers.dev',publicKey:keys.public,lastSync,syncError});
    if(req.method==='POST'){
      if(req.headers.origin!==origin||req.headers['x-owner-csrf']!==csrf||req.headers['content-type']?.split(';')[0]!=='application/json')return json(res,403,{error:'Origem ou sessão inválida. Recarregue o painel.'});
      let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>8192)return json(res,413,{error:'Requisição muito grande.'});}const body=JSON.parse(raw||'{}');
      // Remote tracker actions do not touch the local license catalog: never queue them behind license sync.
      if(url.pathname==='/api/tracker'){
        if(!['tracker-state','tracker-save','tracker-grant','tracker-create','tracker-revoke','tracker-cloud-status','tracker-cloud-start','tracker-cloud-stop','tracker-cloud-reconnect'].includes(body.action))throw Error('Ação inválida.');
        return json(res,200,await cloud(body.action,crypto.randomUUID(),{guildIds:body.guildIds,autoCollect:body.autoCollect,userId:body.userId,label:body.label,collectorId:body.collectorId}));
      }
      if(url.pathname==='/api/refresh')return json(res,200,await scheduleSync());
      const run=async()=>{
        if(url.pathname==='/api/config'){
          const u=new URL(body.siteUrl);if(u.protocol!=='https:'||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('Use somente a origem HTTPS do site.');const team=new URL(body.teamUrl||config.teamUrl||'https://exorcizar-admin.yeencapa011.workers.dev');if(team.protocol!=='https:'||team.username||team.password||team.pathname!=='/'||team.search||team.hash)throw Error('Use a origem HTTPS da API de equipe.');config={siteUrl:u.origin,teamUrl:team.origin};await write('config.json',config);return {ok:true};
        }
        if(url.pathname==='/api/proof'){
          if(!['status','revoke','reset'].includes(body.action)||!licenses.some(x=>x.id===body.id))throw Error('Operação ou licença inválida.');
          return {proof:await sign({kind:'owner',v:1,action:body.action,id:body.id,at:Date.now(),nonce:crypto.randomUUID()},keys.private)};
        }
        if(url.pathname==='/api/sync'){
          const row=licenses.find(x=>x.id===body.id);if(!row)throw Error('Licença não encontrada.');const remote=body.record;
          if(remote&&remote.id!==row.id)throw Error('Registro não corresponde à licença.');
          if(remote){row.remote=remote;row.status=remote.revoked?'revogada':remote.expiresAt&&remote.expiresAt<=Date.now()?'expirada':remote.userId?'ativa':remote.activatedAt?'vínculo resetado':'aguardando ativação';}else row.status='aguardando ativação';await write('licencas.json',licenses);return {ok:true};
        }
        if(url.pathname==='/api/create'){
          if(!Object.hasOwn(PLANS,body.plan))throw Error('Escolha 7 dias, 30 dias, 1 ano ou vitalícia.');
          const count=Number(body.count||1);if(!Number.isInteger(count)||count<1||count>100)throw Error('Quantidade: de 1 a 100.');
          const created=[];for(let i=0;i<count;i++){const id=crypto.randomUUID(),createdAt=Date.now();const key='EXC.'+await sign({kind:'license',v:1,id,plan:body.plan,createdAt},keys.private);created.push({id,key,plan:body.plan,createdAt,note:String(body.note||'').slice(0,120),status:'aguardando ativação'});}licenses.unshift(...created);await write('licencas.json',licenses);let warning=null;try{await syncTeam();}catch(e){syncError=e.message;warning='Keys salvas neste PC; sincronização pendente: '+e.message;}return {created,warning};
        }
        if(['/api/revoke','/api/reset','/api/status'].includes(url.pathname)){
          const row=licenses.find(x=>x.id===body.id);if(!row)throw Error('Licença não encontrada.');
          const action=url.pathname.split('/').pop();const result=await cloud(action,row.id);
          row.checkedAt=Date.now();row.remote=result.record??null;row.status=status(row);await write('licencas.json',licenses);return result;
        }
        throw Error('Rota inexistente.');
      };
      const job=queue.then(run);queue=job.catch(()=>{});return json(res,200,await job);
    }
    const files={'/':'index.html','/owner.js':'owner.js','/owner.css':'owner.css','/logo.png':'logo.png','/status.js':'status.js'};
    if(req.method!=='GET'||!files[url.pathname])return json(res,404,{error:'Não encontrado.'});
    const file=files[url.pathname];res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':file.endsWith('.png')?'image/png':'text/html; charset=utf-8');res.end(await fs.readFile(path.join(root,'public',file)));
  }catch(e){json(res,400,{error:e.message||'Não foi possível concluir.'});}
});
const timer=setInterval(()=>{void scheduleSync().catch(()=>{});},30000);timer.unref();
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'A porta do dono já está ocupada. Feche o CMD do painel antigo e abra esta versão novamente.':'Não foi possível iniciar o painel: '+e.message);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>console.log(`Painel do dono: ${origin}\nMantenha uma cópia segura da pasta dados. Feche esta janela para encerrar.`));
export {server};
