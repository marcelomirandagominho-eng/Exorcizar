@echo off
chcp 65001 >nul
cd /d "%~dp0nuvem"
set CI=true
set WRANGLER_LOG=log
node preparar.mjs
if errorlevel 1 goto erro
call npm ci --no-audit --no-fund
if errorlevel 1 goto erro
call npx wrangler login
if errorlevel 1 goto erro
call npx wrangler d1 migrations apply DB --remote
if errorlevel 1 goto erro
call npx wrangler deploy
if errorlevel 1 goto erro
echo API de equipe publicada. Abra INICIAR-DONO.bat.
pause
exit /b 0
:erro
echo Publicacao interrompida. Confira o erro acima.
pause
exit /b 1
