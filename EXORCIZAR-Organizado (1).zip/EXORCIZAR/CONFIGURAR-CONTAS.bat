@echo off
cd /d "%~dp0EXORCIZAR-Tracker-Nuvem"
start /wait notepad "contas\tokens.txt"
echo Para enviar a lista editada para a Cloudflare, execute PUBLICAR-COLETOR-NUVEM.bat.
pause
