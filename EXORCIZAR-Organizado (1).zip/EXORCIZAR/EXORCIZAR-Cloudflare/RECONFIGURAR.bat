@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Instale Node.js 22.12 ou superior e abra novamente.
 pause
 exit /b 1
)
node -e "const a=process.versions.node.split('.').map(Number);if(a[0]<22||(a[0]===22&&a[1]<12))process.exit(1)"
if errorlevel 1 (
 echo Atualize o Node.js para 22.12 ou superior.
 pause
 exit /b 1
)
echo Preparando o publicador...
call npm ci --no-audit --no-fund
if errorlevel 1 (
 echo A instalacao falhou. A publicacao nao foi iniciada.
 pause
 exit /b 1
)
node publicar.mjs --configurar
pause
