import {proxyTracker} from './tracker-lib/bridge.js';
import {createTracker} from './tracker-lib/service.js';
const LC_PLANS=Object.freeze({'7d':{days:7,label:'7 dias'},'30d':{days:30,label:'30 dias'},'1y':{days:365,label:'1 ano'},lifetime:{days:null,label:'Vitalícia'}});
const lcEncoder=new TextEncoder();
const lcEncode=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const lcDecode=value=>{if(!/^[A-Za-z0-9_-]+$/.test(value))throw Error();return Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));};
const lcUUID=value=>typeof value==='string'&&/^[a-f\d]{8}-[a-f\d]{4}-[a-f\d]{4}-[a-f\d]{4}-[a-f\d]{12}$/i.test(value);
const lcDigest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',lcEncoder.encode(value))),x=>x.toString(16).padStart(2,'0')).join('');
class LicenseError extends Error{constructor(message,status=400,code='LICENSE_INVALID'){super(message);this.status=status;this.code=code;}}
function lcPublicKey(env){try{const jwk=JSON.parse(env.OWNER_PUBLIC_JWK||'null');if(!jwk||jwk.kty!=='EC'||jwk.crv!=='P-256'||jwk.d||!/^[-\w]{43}$/.test(jwk.x)||!/^[-\w]{43}$/.test(jwk.y))throw Error();return {kty:'EC',crv:'P-256',x:jwk.x,y:jwk.y};}catch{throw new LicenseError('O gerador do dono ainda não foi vinculado ao site.',503,'ISSUER_NOT_CONFIGURED');}}
async function lcIssuer(env){return lcDigest(JSON.stringify(lcPublicKey(env)));}
async function lcVerify(value,env,kind='license',now=Date.now()){
 const jwk=lcPublicKey(env);
 try{if(typeof value!=='string'||value.length>4096)throw Error();const [body,sig,...extra]=value.replace(/^EXC\./,'').split('.');if(!body||!sig||extra.length)throw Error();const key=await crypto.subtle.importKey('jwk',jwk,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,lcDecode(sig),lcEncoder.encode(body)))throw Error();const payload=JSON.parse(new TextDecoder().decode(lcDecode(body)));if(payload.kind!==kind||payload.v!==1||!lcUUID(payload.id))throw Error();if(kind==='license'&&(!Object.hasOwn(LC_PLANS,payload.plan)||!Number.isSafeInteger(payload.createdAt)||payload.createdAt<1||payload.createdAt>now+300000))throw Error();if(kind==='owner'&&(!['status','revoke','reset','tracker-state','tracker-save','tracker-grant','tracker-create','tracker-revoke'].includes(payload.action)||!Number.isSafeInteger(payload.at)||Math.abs(now-payload.at)>60000||!lcUUID(payload.nonce)))throw Error();return payload;}catch{throw new LicenseError(kind==='owner'?'Autorização do dono inválida ou expirada.':'Assinatura ou key inválida.',401);}
}
function lcDB(env){if(!env.DB?.prepare)throw new LicenseError('O registro de licenças está indisponível.',503,'LICENSE_STORAGE_UNAVAILABLE');return env.DB.withSession?env.DB.withSession('first-primary'):env.DB;}
function lcView(row,sessionExpiresAt){return {id:row.id,plan:row.plan,label:LC_PLANS[row.plan].label,activatedAt:row.activated_at,expiresAt:row.expires_at,sessionExpiresAt};}
async function lcActivate(raw,discordId,env,now=Date.now()){
 const payload=await lcVerify(raw,env,'license',now);if(typeof discordId!=='string'||!/^\d{15,25}$/.test(discordId))throw new LicenseError('Vincule seu Discord antes de ativar a key.',403,'DISCORD_LINK_REQUIRED');
 const db=lcDB(env),keyHash=await lcDigest(raw.trim().replace(/^EXC\./,'')),days=LC_PLANS[payload.plan].days,expiry=days===null?null:now+days*86400000;
 const results=await db.batch([
 db.prepare('INSERT INTO licenses (id,plan,key_hash,created_at,activated_at,expires_at,discord_id,revoked,revision) VALUES (?,?,?,?,?,?,?,0,0) ON CONFLICT(id) DO UPDATE SET discord_id=excluded.discord_id WHERE licenses.revoked=0 AND (licenses.discord_id IS NULL OR licenses.discord_id=excluded.discord_id) AND licenses.key_hash=excluded.key_hash AND (licenses.expires_at IS NULL OR licenses.expires_at>?)').bind(payload.id,payload.plan,keyHash,payload.createdAt,now,expiry,discordId,now),
 db.prepare('SELECT * FROM licenses WHERE id=?').bind(payload.id)
 ]);
 const row=results[1].results[0];if(row?.revoked)throw new LicenseError('Essa key foi revogada.',403,'LICENSE_REVOKED');if(row?.expires_at!==null&&row?.expires_at<=now)throw new LicenseError('Essa key expirou.',401,'LICENSE_EXPIRED');if(!row||row.key_hash!==keyHash||row.plan!==payload.plan)throw new LicenseError('Essa key não corresponde ao registro da licença.',401);if(row.discord_id!==discordId)throw new LicenseError('Essa key já está vinculada a outra conta Discord.',403,'LICENSE_BOUND');return {...row,issuer:await lcIssuer(env)};
}
async function lcSession(data,discordId,env,now=Date.now()){
 if(!Number.isSafeInteger(data.exp)||data.exp<=now||data.userId!==discordId||data.issuer!==await lcIssuer(env))return null;
 const row=await lcDB(env).prepare('SELECT * FROM licenses WHERE id=?').bind(data.id).first();
 if(!row||row.revoked||row.discord_id!==discordId||row.revision!==data.revision||!Object.hasOwn(LC_PLANS,row.plan)||(row.expires_at!==null&&row.expires_at<=now))return null;return lcView(row,data.exp);
}
async function lcOwner(proof,env,now=Date.now()){
 const payload=await lcVerify(proof,env,'owner',now),db=lcDB(env);const statements=[db.prepare('DELETE FROM owner_nonces WHERE expires_at<?').bind(now),db.prepare('INSERT INTO owner_nonces (nonce,expires_at) VALUES (?,?)').bind(payload.nonce,now+120000)];
 if(payload.action==='revoke')statements.push(db.prepare('INSERT INTO licenses (id,revoked,revision) VALUES (?,1,1) ON CONFLICT(id) DO UPDATE SET revoked=1,revision=licenses.revision+1').bind(payload.id));
 if(payload.action==='reset')statements.push(db.prepare('UPDATE licenses SET discord_id=NULL,revision=revision+1 WHERE id=? AND revoked=0').bind(payload.id));
 statements.push(db.prepare('SELECT * FROM licenses WHERE id=?').bind(payload.id));
 let results;try{results=await db.batch(statements);}catch(e){if(String(e.message).includes('UNIQUE constraint failed: owner_nonces.nonce'))throw new LicenseError('Esta autorização já foi utilizada. Tente a ação novamente pelo painel do dono.',409,'OWNER_REPLAY');throw e;}
 const row=results.at(-1).results[0];return {ok:true,action:payload.action,record:row?{id:row.id,plan:row.plan,userId:row.discord_id,activatedAt:row.activated_at,expiresAt:row.expires_at,revoked:!!row.revoked,revision:row.revision}:null};
}

const oaEncoder=new TextEncoder();
const oaB64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const oaUnb64=text=>Uint8Array.from(atob(text.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
const oaRead=(req,name)=>(req.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1)||'';
const oaCookie=value=>`exc_oauth=${value}; Path=/api/discord-oauth; HttpOnly; Secure; SameSite=Lax; Max-Age=${value?600:0}`;
const oaJson=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
function oauthConfig(env){let guilds;try{guilds=JSON.parse(env.DISCORD_JOIN_GUILDS_JSON||'[]')}catch{guilds=[]}if(!Array.isArray(guilds)||guilds.length<1||guilds.length>5)return {enabled:false,guilds:[]};const seen=new Set();if(guilds.some(g=>!g||typeof g.id!=='string'||!/^\d{15,25}$/.test(g.id)||typeof g.name!=='string'||!g.name.trim()||g.name.length>64||seen.has(g.id)||(seen.add(g.id),false)))return {enabled:false,guilds:[]};return {enabled:/^\d{15,25}$/.test(env.DISCORD_CLIENT_ID||'')&&!!env.DISCORD_CLIENT_SECRET&&!!env.DISCORD_BOT_TOKEN,guilds:guilds.map(g=>({id:g.id,name:g.name.trim()}))};}
async function oaKey(env){const key=await crypto.subtle.digest('SHA-256',oaEncoder.encode('exorcizar/oauth-state/v1\0'+env.SESSION_SECRET));return crypto.subtle.importKey('raw',key,'AES-GCM',false,['encrypt','decrypt']);}
async function oaSeal(data,env){const iv=crypto.getRandomValues(new Uint8Array(12));const body=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},await oaKey(env),oaEncoder.encode(JSON.stringify(data))));const bytes=new Uint8Array(12+body.length);bytes.set(iv);bytes.set(body,12);return oaB64(bytes);}
async function oaOpen(value,env){try{if(!value||value.length>3900)return null;const bytes=oaUnb64(value);return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes.slice(0,12)},await oaKey(env),bytes.slice(12))));}catch{return null;}}
function createDiscordOAuth(validateLicense,requestImpl=(url,init)=>globalThis.fetch(url,init)){
 const consumed=new Map();
 function finish(origin,status,reference=''){const url=new URL('/',origin);url.searchParams.set('community',status);if(reference)url.searchParams.set('community_ref',reference);url.hash='community';return new Response(null,{status:303,headers:{Location:url.href,'Set-Cookie':oaCookie(''),'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});}
 async function linkedProfile(req,env){const url=new URL(req.url),config=oauthConfig(env);const receipt=await oaOpen(oaRead(req,'exc_community'),env);return receipt?.kind==='community'&&receipt.exp>Date.now()&&receipt.origin===url.origin&&receipt.identity===(req.headers.get('oai-authenticated-user-id')||'')&&receipt.client===env.DISCORD_CLIENT_ID&&JSON.stringify(receipt.guilds)===JSON.stringify(config.guilds)?receipt.profile:null;}
 async function handle(req,env){const url=new URL(req.url),config=oauthConfig(env),path=url.pathname;
  if(path==='/api/discord-oauth/config'&&req.method==='GET'){const linked=await linkedProfile(req,env);return oaJson({...config,linked});}
  if(path==='/api/discord-oauth/start'&&req.method==='GET'){
   if(!config.enabled)return oaJson({error:'A entrada na comunidade ainda não foi configurada.'},503);
   const state=oaB64(crypto.getRandomValues(new Uint8Array(32))),redirectUri=url.origin+'/api/discord-oauth/callback';
   const data={kind:'state',state,identity:req.headers.get('oai-authenticated-user-id')||'',client:env.DISCORD_CLIENT_ID,guilds:config.guilds,exp:Date.now()+600000,origin:url.origin};
   const authorization=new URL('https://discord.com/oauth2/authorize');authorization.search=new URLSearchParams({client_id:env.DISCORD_CLIENT_ID,response_type:'code',redirect_uri:redirectUri,scope:'identify guilds.join',state,prompt:'consent'}).toString();
   return new Response(null,{status:302,headers:{Location:authorization.href,'Set-Cookie':oaCookie(await oaSeal(data,env)),'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});
  }
  if(path==='/api/discord-oauth/callback'&&req.method==='GET'){
   const data=await oaOpen(oaRead(req,'exc_oauth'),env);
   if(!data||data.kind!=='state'||!Number.isFinite(data.exp)||data.exp<Date.now()||data.origin!==url.origin||data.state!==url.searchParams.get('state')||data.client!==env.DISCORD_CLIENT_ID||data.identity!==(req.headers.get('oai-authenticated-user-id')||'')||JSON.stringify(data.guilds)!==JSON.stringify(config.guilds))return finish(url.origin,'invalid_state');
   if(!config.enabled)return finish(url.origin,'unavailable');
   if(consumed.has(data.state))return finish(url.origin,'invalid_state');
   if(url.searchParams.get('error'))return finish(url.origin,'cancelled');
   const code=url.searchParams.get('code');if(!code||code.length>2048)return finish(url.origin,'invalid_state');
   consumed.set(data.state,data.exp);for(const [key,expires]of consumed)if(expires<Date.now())consumed.delete(key);
   const reference=crypto.randomUUID();let stage='token',completed=0;
   try{
    const exchange=await requestImpl('https://discord.com/api/v10/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:env.DISCORD_CLIENT_ID,client_secret:env.DISCORD_CLIENT_SECRET,grant_type:'authorization_code',code,redirect_uri:url.origin+'/api/discord-oauth/callback'}).toString(),redirect:'manual',signal:AbortSignal.timeout(12000)});
    if(!exchange.ok)throw Error('token');const token=await exchange.json();const scopes=typeof token.scope==='string'?token.scope.split(' '):[];
    if(typeof token.access_token!=='string'||!scopes.includes('identify')||!scopes.includes('guilds.join'))throw Error('scopes');
    stage='identify';const profileResponse=await requestImpl('https://discord.com/api/v10/users/@me',{headers:{Authorization:'Bearer '+token.access_token},redirect:'manual',signal:AbortSignal.timeout(12000)});if(!profileResponse.ok)throw Error('identify');const profile=await profileResponse.json();if(!/^\d{15,25}$/.test(profile?.id)||profile.bot)throw Error('identity');
    stage='join';let added=0,pending=false,failed=0;
    for(let index=0;index<config.guilds.length;index++){
     const guild=config.guilds[index];const result=await requestImpl('https://discord.com/api/v10/guilds/'+guild.id+'/members/'+profile.id,{method:'PUT',headers:{Authorization:'Bot '+env.DISCORD_BOT_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({access_token:token.access_token}),redirect:'manual',signal:AbortSignal.timeout(12000)});
     if(result.status===201||result.status===204){added++;completed++;if(result.status===201){try{pending=!!(await result.json()).pending||pending}catch{}}}
     else{failed++;let discordCode=0;try{discordCode=Number((await result.json()).code)||0}catch{}console.warn('oauth_join_failure',{reference,index,status:result.status,discordCode});}
    }
    // Access and refresh tokens are not persisted. Joining is a one-time authorized action.
    const result=finish(url.origin,failed?(added?'partial':'failed'):(pending?'pending':'joined'),failed?reference:'');if(!failed){const receipt=await oaSeal({kind:'community',identity:data.identity,client:data.client,guilds:data.guilds,origin:data.origin,profile:{id:profile.id,name:String(profile.global_name||profile.username||'Conta Discord').slice(0,80)},exp:Date.now()+2592000000},env);result.headers.append('Set-Cookie',`exc_community=${receipt}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=2592000`);}return result;
   }catch{console.warn('oauth_join_failure',{reference,stage});return finish(url.origin,completed?'partial':'failed',reference);}
  }
  return oaJson({error:'Rota não encontrada.'},404);
 }
 return {handle,linkedProfile};
}

const DC_TTL=2592000;
const dcEnc=new TextEncoder();
const dcEncode=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const dcDecode=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
const dcJson=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const dcCookie=(value,remember=true)=>`exc_discord=${value}; Path=/api; HttpOnly; Secure; SameSite=Strict${value?(remember?`; Max-Age=${DC_TTL}`:''):'; Max-Age=0'}`;
const dcRead=(req,name)=>(req.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1)||'';
const dcBinding=req=>dcRead(req,'exc_preview');
async function dcKey(env){const digest=await crypto.subtle.digest('SHA-256',dcEnc.encode('exorcizar/discord/v1\0'+env.SESSION_SECRET));return crypto.subtle.importKey('raw',digest,'AES-GCM',false,['encrypt','decrypt']);}
async function dcSeal(data,req,env){const iv=crypto.getRandomValues(new Uint8Array(12));const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:dcEnc.encode(dcBinding(req))},await dcKey(env),dcEnc.encode(JSON.stringify({...data,exp:Date.now()+DC_TTL*1000})));const bytes=new Uint8Array(12+cipher.byteLength);bytes.set(iv);bytes.set(new Uint8Array(cipher),12);return dcEncode(bytes);}
async function dcOpen(req,env){try{const value=dcRead(req,'exc_discord');if(!value||value.length>3800||!dcBinding(req))return null;const bytes=dcDecode(value),raw=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes.slice(0,12),additionalData:dcEnc.encode(dcBinding(req))},await dcKey(env),bytes.slice(12));const data=JSON.parse(new TextDecoder().decode(raw));return typeof data.token==='string'&&/^\d{15,25}$/.test(data.user?.id)&&data.exp>Date.now()?data:null;}catch{return null;}}
const dcId=value=>typeof value==='string'&&/^\d{15,25}$/.test(value);
async function dcProofKey(env){return crypto.subtle.importKey('raw',dcEnc.encode('delete-proof/v1\0'+env.SESSION_SECRET),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
async function dcMakeProof(key,req,auth,channelId,messageId){const body=dcEncode(dcEnc.encode(JSON.stringify({u:auth.user.id,c:channelId,m:messageId,e:Date.now()+3600000})));const signature=await crypto.subtle.sign('HMAC',key,dcEnc.encode(dcBinding(req)+'\0'+body));return body+'.'+dcEncode(signature);}
async function dcVerifyProof(proof,req,env,auth,channelId,messageId){try{if(typeof proof!=='string'||proof.length>1000)return false;const [body,sig,...rest]=proof.split('.');if(rest.length||!sig)return false;const valid=await crypto.subtle.verify('HMAC',await dcProofKey(env),dcDecode(sig),dcEnc.encode(dcBinding(req)+'\0'+body));if(!valid)return false;const data=JSON.parse(new TextDecoder().decode(dcDecode(body)));return data.u===auth.user.id&&data.c===channelId&&data.m===messageId&&Number.isFinite(data.e)&&data.e>Date.now();}catch{return false;}}

class DcError extends Error{constructor(message,status=400,retryAfter=0){super(message);this.status=status;this.retryAfter=retryAfter;}}
function createDiscordService(requestImpl=(input,init)=>globalThis.fetch(input,init)){
 const cooldowns=new Map(),inFlight=new Set();
 async function call(auth,path,method='GET',body){
  const stamp=await crypto.subtle.digest('SHA-256',dcEnc.encode(auth.token));const tokenId=dcEncode(stamp);const until=cooldowns.get(tokenId)||0;
  if(until>Date.now())throw new DcError('O Discord pediu uma pausa. Aguarde a contagem.',429,(until-Date.now())/1000);
  if(cooldowns.size>1000)for(const [k,t]of cooldowns)if(t<Date.now())cooldowns.delete(k);
  if(inFlight.has(tokenId)){const error=new DcError('Aguarde a chamada anterior terminar.',429,1);error.code='APP_REQUEST_IN_PROGRESS';throw error;}
  inFlight.add(tokenId);
  try{
  let res;try{res=await requestImpl('https://discord.com/api/v10'+path,{method,headers:{Authorization:auth.token,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),redirect:'manual',signal:AbortSignal.timeout(12000)});}catch(error){const message=String(error?.message||'');const reason=/Illegal invocation|this reference/i.test(message)?'FETCH_RECEIVER':/AbortSignal|timeout.*function/i.test(message)?'FETCH_TIMEOUT_API':error?.name==='TimeoutError'||error?.name==='AbortError'?'FETCH_TIMEOUT':/blocked|denied|not allowed|egress/i.test(message)?'FETCH_RESTRICTED':'FETCH_NETWORK';const reference=crypto.randomUUID();console.error('discord_transport_failure',{reference,reason,name:typeof error?.name==='string'?error.name.slice(0,40):'Error'});const failure=new DcError(reason==='FETCH_TIMEOUT'?'O Discord não respondeu no tempo limite. Tente novamente.':'A hospedagem não conseguiu chamar o Discord. Código: '+reason+'.',502);failure.code=reason;failure.details={reference,operation:method+' '+path.replace(/\d{15,25}/g,':id').split('?')[0],httpStatus:502};throw failure;}
  if(res.status>=300&&res.status<400){const error=new DcError('O Discord retornou um redirecionamento inesperado. A chamada foi interrompida.',502);error.code='DISCORD_REDIRECT';throw error;}
  let data=null;try{data=await res.json();}catch{}
  if(res.status===429){const seconds=Math.min(3600,Math.max(1,Number(data?.retry_after)||Number(res.headers.get('Retry-After'))||5));cooldowns.set(tokenId,Date.now()+seconds*1000);throw new DcError('O Discord pediu uma pausa. Aguarde a contagem.',429,seconds);}
  if(!res.ok){const status=res.status,discordCode=Number.isInteger(data?.code)?data.code:0;const route=path.replace(/\d{15,25}/g,':id').split('?')[0];const reference=crypto.randomUUID();console.warn('discord_api_failure',{reference,method,route,status,discordCode});const note=discordCode?' Código Discord: '+discordCode+'.':'';const error=new DcError((status===401?'Token inválido ou sessão revogada. Conecte novamente.':status===403?'O Discord recusou esta operação.':status===404?'Conversa, servidor ou mensagem não encontrado.':'O Discord recusou a operação.')+note,[401,403,404].includes(status)?status:502);error.discordCode=discordCode;error.code='DISCORD_HTTP_'+status;error.details={reference,operation:method+' '+route,httpStatus:status,discordCode:discordCode||null,discordMessage:typeof data?.message==='string'?data.message.replaceAll(auth.token,'[oculto]').replace(/[\r\n\t]/g,' ').slice(0,240):null};throw error;}
  const remaining=res.headers.get('X-RateLimit-Remaining'),reset=Number(res.headers.get('X-RateLimit-Reset-After'));
  if(remaining==='0'&&reset>0)cooldowns.set(tokenId,Date.now()+Math.min(reset,3600)*1000);
  return data;
  }finally{inFlight.delete(tokenId);}
 }
 async function handle(req,env){
  try{
   if(req.method!=='POST')return dcJson({error:'Método não permitido.'},405);
   const raw=await req.text();if(raw.length>7000)return dcJson({error:'Requisição muito grande.'},413);
   let body;try{body=JSON.parse(raw||'{}')}catch{return dcJson({error:'Dados inválidos.'},400)}
   if(!body||typeof body!=='object')return dcJson({error:'Dados inválidos.'},400);
   const action=new URL(req.url).pathname.slice('/api/discord/'.length);
   if(action==='disconnect'){const res=dcJson({ok:true});res.headers.set('Set-Cookie',dcCookie(''));return res;}
   if(action==='connect'){
    if(typeof body.token!=='string'||body.token.trim().length<25||body.token.length>2048||/[\r\n]/.test(body.token))return dcJson({error:'Informe um token válido.'},400);
    const token=body.token.trim(),user=await call({token},'/users/@me');
    if(!dcId(user?.id)||user.bot)throw new DcError('Use apenas o token da sua própria conta pessoal.');
    const profile={id:user.id,name:user.global_name||user.username||'Conta conectada'};
    const value=await dcSeal({token,user:profile},req,env);const res=dcJson({ok:true,user:profile});res.headers.set('Set-Cookie',dcCookie(value,body.remember===true));return res;
   }
   const auth=await dcOpen(req,env);if(!auth)return dcJson({error:'Conecte sua conta para usar as ferramentas.'},401);
   if(action==='status'){const user=await call(auth,'/users/@me');if(user?.id!==auth.user.id)throw new DcError('A conta conectada mudou. Conecte novamente.',401);return dcJson({connected:true,user:auth.user});}
   if(action==='plan'){
    if(!['user','global','server','ghost','autoclear'].includes(body.mode))throw new DcError('Esta função ainda não está disponível nesta versão.');
    if(body.confirm!=='APAGAR')throw new DcError('Confirme a exclusão permanente para continuar.');
    let channels;
    if(body.mode==='global'){channels=await call(auth,'/users/@me/channels');if(!Array.isArray(channels))throw new DcError('O Discord não retornou as conversas.',502);channels=channels.filter(c=>c.type===1);}
    else if(body.mode==='server'){
     if(!dcId(body.target))throw new DcError('Informe um ID de servidor válido.');
     channels=await call(auth,'/guilds/'+body.target+'/channels');if(!Array.isArray(channels))throw new DcError('Não foi possível listar os canais.',502);channels=channels.filter(c=>c.type===0);
    }else{
     if(!dcId(body.target))throw new DcError('Informe um ID válido de usuário ou DM.');
     let channel;try{channel=await call(auth,'/channels/'+body.target);}catch(e){if(![403,404].includes(e.status))throw e;channel=await call(auth,'/users/@me/channels','POST',{recipient_id:body.target});}
     if(channel?.type!==1)throw new DcError('Essa função precisa de uma conversa DM individual.');channels=[channel];
    }
    return dcJson({channels:channels.filter(c=>dcId(c.id)).map(c=>({id:c.id,name:body.mode==='server'?(c.name||c.id):'DM '+c.id})),user:auth.user});
   }
   if(!dcId(body.channelId))throw new DcError('ID de conversa inválido.');
   const channelPath='/channels/'+body.channelId;
   if(action==='page'){
    if(body.before&&!dcId(body.before))throw new DcError('Cursor inválido.');
    const items=await call(auth,channelPath+'/messages?limit=100'+(body.before?'&before='+body.before:''));
    if(!Array.isArray(items))throw new DcError('Resposta de mensagens inválida.',502);
    const own=items.filter(m=>m.author?.id===auth.user.id&&dcId(m.id));
    const proofKey=await dcProofKey(env);const messages=await Promise.all(own.map(async m=>({id:m.id,timestamp:m.timestamp,proof:await dcMakeProof(proofKey,req,auth,body.channelId,m.id)})));
    return dcJson({messages,scanned:items.length,next:items.length===100?items.at(-1)?.id:null,latest:items[0]?.id||null});
   }
   if(action==='delete'){
    if(body.confirm!=='APAGAR'||!dcId(body.messageId))throw new DcError('Confirmação ou ID de mensagem inválido.');
    if(!await dcVerifyProof(body.proof,req,env,auth,body.channelId,body.messageId))throw new DcError('A autorização desta mensagem está ausente ou expirou. Reinicie a limpeza.',403);
    try{await call(auth,channelPath+'/messages/'+body.messageId,'DELETE');}catch(e){if(e.status===404)return dcJson({deleted:false,alreadyGone:true});if(e.discordCode===50021)return dcJson({deleted:false,skipped:true,reason:'SYSTEM_MESSAGE'});throw e;}
    return dcJson({deleted:true});
   }
   if(action==='close'){
    if(body.confirm!=='APAGAR')throw new DcError('Confirme a operação.');const channel=await call(auth,channelPath);if(channel?.type!==1)throw new DcError('Só é permitido fechar DMs individuais.',403);await call(auth,channelPath,'DELETE');return dcJson({ok:true});
   }
   return dcJson({error:'Função não encontrada.'},404);
  }catch(e){const res=dcJson({error:e instanceof DcError?e.message:'A operação falhou. Tente novamente.',...(e.code?{code:e.code}:{}),details:e.details||{reference:crypto.randomUUID(),operation:'API '+new URL(req.url).pathname.replace(/\d{15,25}/g,':id').slice(0,100),httpStatus:e instanceof DcError?e.status:500},...(e.retryAfter?{retryAfter:e.retryAfter}:{})},e instanceof DcError?e.status:500);if(e.status===401)res.headers.set('Set-Cookie',dcCookie(''));return res;}
 }
 return {handle};
}

const discordService=createDiscordService();
const discordOAuth=createDiscordOAuth((req,env)=>session(req,env));
const enc = new TextEncoder();
const b64 = a => btoa(String.fromCharCode(...new Uint8Array(a))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const unb64 = s => Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
const headers = {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'};
const json = (data,status=200,extra={}) => new Response(JSON.stringify(data),{status,headers:{...headers,'Content-Type':'application/json',...extra}});
const hash = async s => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(s))),x=>x.toString(16).padStart(2,'0')).join('');
async function signingKey(env){return crypto.subtle.importKey('raw',enc.encode(env.SESSION_SECRET),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
function licenses(env){try{return JSON.parse(env.ALLOWED_LICENSES_JSON||'{}')}catch{return {}}}
const cookie = value => `exc_preview=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${value?2592000:0}`;
async function session(req,env){
 try {
  const value=(req.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('exc_preview='))?.slice(12);
  if(!value || !env.SESSION_SECRET)return null;
  const [body,sig,...rest]=value.split('.'); if(rest.length)return null;
  if(!await crypto.subtle.verify('HMAC',await signingKey(env),unb64(sig),enc.encode(body)))return null;
  const data=JSON.parse(new TextDecoder().decode(unb64(body)));
  if(data.kind==='signed-license'){const linked=await discordOAuth.linkedProfile(req,env);return linked?await lcSession(data,linked.id,env):null;}
  if(env.OWNER_PUBLIC_JWK)return null;
  if(!Number.isFinite(data.exp)||data.exp<=Date.now()||!licenses(env)[data.hash])return null;
  return {plan:licenses(env)[data.hash].plan,label:licenses(env)[data.hash].label,expiresAt:null,sessionExpiresAt:data.exp};
 }catch{return null;}
}
const tracker=createTracker({verifyOwner:(proof,env)=>lcVerify(proof,env,'owner'),session,linked:(req,env)=>discordOAuth.linkedProfile(req,env)});
export default {async fetch(req,env){
 const cleanHeaders=new Headers(req.headers);for(const key of [...cleanHeaders.keys()])if(key.startsWith('oai-authenticated-'))cleanHeaders.delete(key);req=new Request(req,{headers:cleanHeaders});
 const url=new URL(req.url), path=url.pathname;
 if(path.startsWith('/api/')){
  if(!env.SESSION_SECRET||env.SESSION_SECRET.length<32)return json({error:'A validação está indisponível. Tente novamente em instantes.'},503);
  if(req.method==='POST'){
   if(req.headers.get('Origin')!==url.origin&&!(['/api/owner/action','/api/tracker/owner','/api/tracker/ingest'].includes(path)&&!req.headers.get('Origin')))return json({error:'Origem não autorizada.'},403);
   if(!req.headers.get('Content-Type')?.startsWith('application/json'))return json({error:'Formato inválido.'},415);
  }
  if(path.startsWith('/api/tracker/'))return env.TRACKER_API_URL?proxyTracker(req,env,{session,linked:(r,e)=>discordOAuth.linkedProfile(r,e)}):tracker.handle(req,env);
  if(path.startsWith('/api/discord-oauth/'))return discordOAuth.handle(req,env);
  if(path==='/api/owner/action'&&req.method==='POST'){try{const raw=await req.text();if(raw.length>8192)return json({error:'Requisição muito grande.'},413);const data=JSON.parse(raw);return json(await lcOwner(data.proof,env));}catch(e){return json({error:e instanceof LicenseError?e.message:'Não foi possível concluir a operação.',code:e.code||'OWNER_ACTION_FAILED'},e instanceof LicenseError?e.status:400);}}
  if(env.DISCORD_LINK_REQUIRED==='true'&&path!=='/api/logout'&&!await discordOAuth.linkedProfile(req,env))return json({error:'Vincule seu Discord antes de ativar a key e acessar o painel.',code:'DISCORD_LINK_REQUIRED'},403);
  if(path.startsWith('/api/discord/')){if(!await session(req,env))return json({error:'Sua sessão da key não está ativa. Entre novamente.',code:'LICENSE_REQUIRED'},401);return discordService.handle(req,env);}
  if(path==='/api/session'&&req.method==='GET'){
   const active=await session(req,env); return active?json({ok:true,license:active}):json({error:'Ative sua key para continuar.'},401);
  }
  if(path==='/api/logout'&&req.method==='POST'){const res=json({ok:true},200,{'Set-Cookie':cookie('')});res.headers.append('Set-Cookie',dcCookie(''));res.headers.append('Set-Cookie','exc_oauth=; Path=/api/discord-oauth; HttpOnly; Secure; SameSite=Lax; Max-Age=0');res.headers.append('Set-Cookie','exc_community=; Path=/api/discord-oauth; HttpOnly; Secure; SameSite=Strict; Max-Age=0');res.headers.append('Set-Cookie','exc_community=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0');return res;}
  if(path==='/api/activate'&&req.method==='POST'){
   if(Number(req.headers.get('Content-Length')||0)>4096)return json({error:'Key inválida.'},400);
   let data;try{const raw=await req.text();if(raw.length>4096)return json({error:'Key inválida.'},400);data=JSON.parse(raw)}catch{return json({error:'Key inválida.'},400)}
   if(typeof data.key!=='string'||data.key.length>2048)return json({error:'Key inválida.'},400);
   if(!env.OWNER_PUBLIC_JWK&&!data.key.trim().startsWith('EXC.')){if(!licenses(env)[await hash(data.key.trim())])return json({error:'Key inválida.'},401);}
   if(env.OWNER_PUBLIC_JWK||!licenses(env)[await hash(data.key.trim())]){try{const linked=await discordOAuth.linkedProfile(req,env);const row=await lcActivate(data.key.trim(),linked?.id,env);const expiresAt=Math.min(Date.now()+2592000000,row.expires_at??Infinity);const body=b64(enc.encode(JSON.stringify({kind:'signed-license',id:row.id,userId:row.discord_id,revision:row.revision,issuer:row.issuer,exp:expiresAt,nonce:crypto.randomUUID()})));const sig=b64(await crypto.subtle.sign('HMAC',await signingKey(env),enc.encode(body)));return json({ok:true,license:lcView(row,expiresAt)},200,{'Set-Cookie':cookie(body+'.'+sig)});}catch(e){return json({error:e instanceof LicenseError?e.message:'Não foi possível validar a licença. Tente novamente.',code:e.code||'LICENSE_UNAVAILABLE'},e instanceof LicenseError?e.status:503);}}
   const digest=await hash(data.key.trim()),license=licenses(env)[digest];
   if(!license)return json({error:'Essa key não está autorizada nesta prévia. Confira se você copiou a key completa.'},401);
   const expiresAt=Date.now()+2592000000;
   const body=b64(enc.encode(JSON.stringify({hash:digest,exp:expiresAt,nonce:crypto.randomUUID()})));
   const sig=b64(await crypto.subtle.sign('HMAC',await signingKey(env),enc.encode(body)));
   return json({ok:true,license:{...license,expiresAt:null,sessionExpiresAt:expiresAt}},200,{'Set-Cookie':cookie(body+'.'+sig)});
  }
  return json({error:'Rota não encontrada.'},404);
 }
 if(req.method!=='GET'&&req.method!=='HEAD')return new Response('Method not allowed',{status:405});
 const assetUrl=new URL(req.url);assetUrl.pathname=path==='/'?'/index.html':path==='/owner-bridge'?'/owner-bridge.html':path;
 const response=await env.ASSETS.fetch(new Request(assetUrl,req));
 const responseHeaders=new Headers(response.headers);for(const [name,value] of Object.entries(headers))responseHeaders.set(name,value);
 responseHeaders.set('Cache-Control',path.startsWith('/assets/')?'public,max-age=3600':'no-cache');
 responseHeaders.set('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; base-uri 'none'; form-action 'self'; object-src 'none'; frame-src 'self'; media-src 'self'; frame-ancestors 'self'");
 return new Response(req.method==='HEAD'?null:response.body,{status:response.status,headers:responseHeaders});
}};
