CREATE TABLE `licenses` (
	`id` text PRIMARY KEY NOT NULL,
	`plan` text,
	`key_hash` text,
	`created_at` integer,
	`activated_at` integer,
	`expires_at` integer,
	`discord_id` text,
	`revoked` integer DEFAULT 0 NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `licenses_key_hash_unique` ON `licenses` (`key_hash`);--> statement-breakpoint
CREATE TABLE `owner_nonces` (
	`nonce` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL
);
