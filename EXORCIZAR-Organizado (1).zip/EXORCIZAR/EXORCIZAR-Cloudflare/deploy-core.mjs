import {readFile,writeFile,rename} from 'node:fs/promises';
import path from 'node:path';
import {randomBytes,webcrypto} from 'node:crypto';
export const ACCOUNT='a03366728c6a2608a8f894b99c07d938';
export const TARGET='https://exorcizar.yeencapa011.workers.dev';
export const DEFAULT_PUBLIC_KEY={kty:'EC',crv:'P-256',x:'eVvY_QlbhrNF5eASBkHrbuv22H6sndE29Zt7KGTFO-Y',y:'aQYdvt7EbU8Lva6ZuWnfwjEPdEq6_TOe22lbE74VDG0'};
export async function validateCredentials(body,configured=false){
 if(configured&&!body.configure)return null;
 let jwk;try{jwk=typeof body.publicKey==='string'?JSON.parse(body.publicKey.trim().replace(/^\uFEFF/,'')):body.publicKey;}catch{throw Error('A chave pública precisa ser um JSON válido.');}
 if(!jwk||jwk.d||jwk.private)throw Error('Use somente a chave pública, nunca o arquivo de assinatura privada.');
 if(jwk.kty!=='EC'||jwk.crv!=='P-256'||!/^[-\w]{43}$/.test(jwk.x)||!/^[-\w]{43}$/.test(jwk.y))throw Error('A chave pública deve ser EC P-256, com os campos x e y.');
 const key={kty:'EC',crv:'P-256',x:jwk.x,y:jwk.y};try{await webcrypto.subtle.importKey('jwk',key,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);}catch{throw Error('Essa chave pública não é válida. Copie novamente do painel do dono.');}
 const client=String(body.clientSecret||'').trim(),bot=String(body.botToken||'').trim();
 if(client.length<10||client.length>2048||/\s/.test(client))throw Error('Confira o Client Secret do aplicativo Discord.');
 if(bot.length>2048||!/^[-\w]+\.[-\w]+\.[-\w]+$/.test(bot))throw Error('Confira o token do BOT do mesmo aplicativo.');
 return {OWNER_PUBLIC_JWK:JSON.stringify(key),DISCORD_CLIENT_SECRET:client,DISCORD_BOT_TOKEN:bot};
}
export function parseOutput(text){text=text.replace(/\x1b\[[0-9;]*m/g,'').replace(/^\uFEFF/,'').trim();try{return JSON.parse(text)}catch{}
 for(let start=0;start<text.length;start++){if(!'[{'.includes(text[start]))continue;let quoted=false,escaped=false,depth=0;for(let end=start;end<text.length;end++){const c=text[end];if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;continue;}if(c==='"')quoted=true;else if(c==='['||c==='{')depth++;else if(c===']'||c==='}'){depth--;if(depth===0){try{return JSON.parse(text.slice(start,end+1))}catch{break;}}}}}throw Error('O Cloudflare não retornou uma resposta JSON válida. Confira o relatório.');
}
export async function loadState(root){try{const state=JSON.parse(await readFile(path.join(root,'.deploy-state.json'),'utf8'));return {configured:state.configured===true};}catch(e){if(e.code==='ENOENT')return {configured:false};throw Error('O estado local está inválido. Renomeie .deploy-state.json e tente novamente.');}}
async function atomic(root,name,data){const dest=path.join(root,name),tmp=dest+'.tmp';await writeFile(tmp,JSON.stringify(data,null,2)+'\n',{mode:0o600});await rename(tmp,dest);}
export function makeRedactor(secrets=[]){return text=>{let output=String(text).replace(/\x1b\[[0-9;]*[A-Za-z]/g,'');for(const value of secrets)if(value)output=output.split(value).join('[OCULTO]');return output.replace(/\b(?:mfa\.[\w-]{15,}|[\w-]{15,}\.[\w-]{5,}\.[\w-]{15,})\b/g,'[TOKEN OCULTO]').replace(/([?&](?:code|token|state)=)[^\s&]+/gi,'$1[OCULTO]');};}
export async function deploy({root,run,emit,credentials,domain=false,fetchImpl=fetch,sleep=ms=>new Promise(r=>setTimeout(r,ms))}){
 const config=JSON.parse(await readFile(path.join(root,'wrangler.json'),'utf8'));
 if(config.name!=='exorcizar'||config.account_id!==ACCOUNT)throw Error('O nome ou a conta do destino mudou. Publicação interrompida.');
 const command=(args,options={})=>run([...args,'--config','wrangler.json'],options);
 emit('1/7 · Conferindo o código e as imagens antes de publicar.');await command(['deploy','--dry-run','--outdir','.preflight']);
 emit('2/7 · Entre no Cloudflare na aba que abrir e autorize o Wrangler.');await command(['login'],{timeout:600000,interactive:true});
 const remote=parseOutput(await command(['secret','list','--format','json'],{capture:true}));if(!Array.isArray(remote))throw Error('Resposta inesperada ao consultar os segredos do Worker.');
 const names=new Set(remote.map(s=>s.name));const required=['OWNER_PUBLIC_JWK','DISCORD_CLIENT_SECRET','DISCORD_BOT_TOKEN'];if(!credentials&&required.some(n=>!names.has(n)))throw Error('Faltam credenciais no Worker. Marque Configurar credenciais e preencha os campos.');
 emit('3/7 · Localizando o banco das keys.');let list=parseOutput(await command(['d1','list','--json'],{capture:true}));if(!Array.isArray(list))throw Error('A lista de bancos retornada é inválida.');let db=list.find(row=>row.name==='exorcizar-licenses');
 if(!db){await command(['d1','create','exorcizar-licenses','--binding','DB','--update-config']);list=parseOutput(await command(['d1','list','--json'],{capture:true}));if(!Array.isArray(list))throw Error('Não foi possível confirmar o banco criado.');db=list.find(row=>row.name==='exorcizar-licenses');}
 if(!db||typeof db.uuid!=='string'||!/^[-a-f\d]{36}$/i.test(db.uuid))throw Error('Não foi possível confirmar o ID do banco. Nenhum banco foi apagado.');
 config.d1_databases=[{binding:'DB',database_name:db.name,database_id:db.uuid,migrations_dir:'migrations'}];if(domain)config.routes=[{pattern:'exorcizam.site',custom_domain:true}];await atomic(root,'wrangler.json',config);
 emit('4/7 · Aplicando as migrations e conferindo as tabelas.');await command(['d1','migrations','apply','DB','--remote']);
 const schema=parseOutput(await command(['d1','execute','DB','--remote','--command',"SELECT COUNT(*) AS ready FROM sqlite_master WHERE type='table' AND name IN ('licenses','owner_nonces','tracker_collectors','tracker_guilds','tracker_grants','tracker_consents','tracker_events','tracker_identity','tracker_history','tracker_settings','tracker_lookups')",'--json'],{capture:true}));if(!Array.isArray(schema)||Number(schema[0]?.results?.[0]?.ready)!==11)throw Error('As tabelas de licenças e tracker não foram confirmadas. O código não foi enviado.');
 emit('5/7 · Configurando as credenciais sem gravá-las em arquivo.');let values=credentials?{...credentials}:{};if(!names.has('SESSION_SECRET'))values.SESSION_SECRET=randomBytes(48).toString('base64url');if(Object.keys(values).length)await command(['secret','bulk'],{input:JSON.stringify(values),privateInput:true});values={};await atomic(root,'.deploy-state.json',{configured:true});
 emit('6/7 · Publicando o site completo no Worker exorcizar.');await command(['deploy']);
 emit('7/7 · Conferindo a resposta pública do site.');let verified=false;for(let attempt=0;attempt<3;attempt++){try{const response=await fetchImpl(TARGET+'/api/discord-oauth/config',{redirect:'manual',signal:AbortSignal.timeout(10000)});const data=response.ok?await response.json():null;if(data?.enabled===true&&data.guilds?.some(g=>g.id==='1570285225756459158')){verified=true;break;}}catch{}if(attempt<2)await sleep(1500);}
 return {published:true,verified,url:domain?'https://exorcizam.site':TARGET,testUrl:TARGET,callback:TARGET+'/api/discord-oauth/callback',domainCallback:'https://exorcizam.site/api/discord-oauth/callback'};
}
