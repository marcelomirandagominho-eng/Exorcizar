(()=>{
 const running=new WeakMap();
 function enter(node,stagger=false){
  if(!node||node.hidden||typeof node.animate!=='function'||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
  running.get(node)?.cancel();
  const animation=node.animate([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'translateY(0)'}],{duration:240,easing:'cubic-bezier(.22,.7,.25,1)'});running.set(node,animation);
  if(stagger){for(const [i,card] of [...node.querySelectorAll('.stats article,.tool-card,.appearance-card')].slice(0,10).entries()){
   running.get(card)?.cancel();running.set(card,card.animate([{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'translateY(0)'}],{duration:220,delay:Math.min(i*24,144),easing:'ease-out',fill:'backwards'}));
  }}
 }
 document.addEventListener('exc:page',()=>enter(document.querySelector('.page:not([hidden])'),true));
 document.addEventListener('exc:tracker-view',()=>{const profile=document.querySelector('#profile'),feed=document.querySelector('.feed-panel');enter(feed&&!feed.hidden?feed:profile);});
 const page=document.querySelector('#dashboard:not([hidden]) .page:not([hidden])');if(page)enter(page,true);
})();
