# Organização aplicada

Mantidos: fonte do site publicado, API/coletor nativo na Cloudflare, painel de dono, configurações das duas contas, segredos locais existentes, licenças e assinatura originais, tokens para reconfiguração, banco legado e testes úteis.

Removidos da entrega: cópia de `Nova pasta`, runtime do coletor local, dependências regeneráveis, caches de Wrangler, saídas de preflight, scripts de reparos anteriores e snapshots temporários redundantes. Os ZIPs originais enviados não foram alterados.

O painel não troca nem renova a validade das keys ao aplicar o rework. A ativação e o vencimento continuam vindo do backend. O ajuste do login nativo ainda precisa de validação com a conta real após publicar.
